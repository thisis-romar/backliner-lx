TOURIST @ MOD CLUB — LX FLOOR PACKAGE
Production lighting deliverables · Emblem Projects
Show date: 26 JUN 2026 · Venue: Mod Club, Toronto ON
Package built: 2026-06-27

------------------------------------------------------------------
CONTENTS
------------------------------------------------------------------
01-drawings-pdf/    Print-ready sheets (open these first):
                      1-floor-plan.pdf
                      2-front-elevation.pdf
                      3-equipment-schedule.pdf
02-drawings-png/    Screen-preview PNGs of the same three sheets.
03-master-sheet/    Full combined sheet:
                      lx-floor-package.png  (rendered)
                      lx-floor-package.svg  (editable vector master)
source/             Secondary / production assets:
  clean-drawings/     drawings with sheet header/footer/legend removed
  svg-layers/         scalable SVGs split by layer (linework / dimensions / accents)
  title-blocks/       title-block column crops
  legends/            symbol legend crops
  debug/              title-block boundary audit overlays

------------------------------------------------------------------
EQUIPMENT
------------------------------------------------------------------
LIGHTING
  4  EA   Moving Head — Robe Pointe LED 330W Hybrid (clone)   MH-1..MH-4
  3  EA   Tilt Strobe — 8x8 RGBW (JDC1 clone)                 ST-1..ST-3
  8  EA   18x10W RGBW PAR64                                   decks + DS flanks
  1  EA   Elation Opto Splitter (5-pin DMX)                   offstage SR
STRUCTURAL
  8  EA   6' Black Threaded Pipe
  8  EA   24" Threaded Base Plate
  2  SET  36" Deck Leg Set (4-pack)                           SR + SL risers
SERVICE
  2  RUN  Transport + Build [City / Truck / 1-Way]

------------------------------------------------------------------
NOTES
------------------------------------------------------------------
Scale: 1:16 (16 px = 1 ft). Stage 40 ft wide x 25 ft deep.
All dimensions approximate and subject to venue confirmation.
Operator must verify structural loads with the venue prior to install.
(c) 2026 Emblem Projects. Prepared for production planning only.
