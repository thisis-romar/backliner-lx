TOURIST — TRANCE TOUR 2026 · SMALL RIG
Production lighting deliverables · SYNRGY  (projects@synrgy.live)
Client: TOURIST · Venue: VARIOUS · Job No: SN0001
DESIGN INTENT ONLY — field-verify all dimensions before fabrication.
Package built: 2026-06-27

------------------------------------------------------------------
CONTENTS
------------------------------------------------------------------
01-drawings-pdf/    Print-ready sheets (open these first):
                      1-plan-view.pdf        (TOURIST US 2026)
                      2-side-elevation.pdf   (TOURIST US 2026)
                      3-front-elevation.pdf  (TOURIST UK/EU 2026)
02-drawings-png/    Screen-preview PNGs of the same three sheets.
03-master-sheet/    Full combined sheet:
                      lx-floor-package.png  (rendered)
                      lx-floor-package.svg  (editable vector master)
source/             Secondary / production assets:
  clean-drawings/     drawings with sheet header/footer/legend removed
  svg-layers/         scalable SVGs split by layer (linework / dimensions / accents)
  title-blocks/       title-block column crops
  legends/            symbol legend crops
  debug/              title-block boundary audit overlays

------------------------------------------------------------------
EQUIPMENT  (per legend)
------------------------------------------------------------------
LIGHTING
  16 EA   LED Par
   6 EA   Ayrton Rivale Profile            (red marker in plan)
   3 EA   Chauvet Color Strike M Strobe
STRUCTURAL
   8 EA   Doughty Tank Trap — 6' (2.4 m) poles on weighted bases
   8 EA   Doughty Tank Trap — 4' (1.2 m) poles on weighted bases
DECKS
  10 EA   4' x 8' decks  (2 rows of 4 horizontal + 2 vertical)

------------------------------------------------------------------
NOTES
------------------------------------------------------------------
Deck layout: two 32'-0" rows (4 x 8' decks each) + two 4'x8' vertical
decks. Gaps between rows and between vertical decks are FIELD VERIFY.
All decks 4' x 8'. Verify all dimensions in field before fabrication.
Scaffold poles (Doughty Tank Trap or similar) on weighted bases.
(c) 2026 SYNRGY. Design intent only — not for construction.
